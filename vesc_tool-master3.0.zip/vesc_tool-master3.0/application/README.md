Create an application with the VESC Tool backend. Usage:  
```bash
./create_app app_name
```
To create a QtQuick app:  
```bash
./create_app app_name qml
```

