This is a GUI written using the Qt toolkit to configure the VESC motor controller. Read more and download precompiled versions at

http://vesc-project.com/
